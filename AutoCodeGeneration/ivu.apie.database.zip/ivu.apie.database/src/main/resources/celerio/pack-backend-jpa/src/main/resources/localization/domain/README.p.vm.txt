$output.domainLocalization("README.txt")##

## Mainly here to create the domain folder as we no longer create it automatically.

This folder contains Resources file for entities.
Note that each base file must be declared in the Spring configuration MessageSourceConfiguration Java class.
